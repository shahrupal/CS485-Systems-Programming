       
This directory contains some examples from our textbook.  

        
